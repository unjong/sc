﻿Clear-Host

$FromDir = "\\10.10.11.20\NugetPackages\Deploy"
$ToDir = "D:\720.YUHS\Useverance3\src\Common\artifacts\Debug"

$sw = [system.diagnostics.stopwatch]::startNew()
$sw.Start()

Get-ChildItem -path $FromDir -recurse -Include "*.dll" |
  Foreach-Object { Copy-Item $_ -Destination $ToDir }
#11.8747187

#XCOPY "\\10.10.11.20\NugetPackages\Deploy\*.dll" "D:\720.YUHS\Useverance3\src\Common\artifacts\Debug" /S /I /Y 
#14.4612212

$Sw.Stop()
$Sw.Elapsed.TotalSeconds

